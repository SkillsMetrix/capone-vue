<template>
    <div>
MealList
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>

</style>