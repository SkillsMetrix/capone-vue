


export default{
    
    searchedMeals:[]
}