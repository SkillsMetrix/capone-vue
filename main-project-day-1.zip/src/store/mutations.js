 
export  function setSearchedMeals(state,meals) {
state.searchedMeals=meals
    
}